<?php 


/**
 * Maps all product images (featured and gallery) to a structured array.
 *
 * @param WC_Product $product The WooCommerce product object.
 * @return array An array of image data containing id, src, and alt.
 */
function map_product_images($product) {
    $image_ids = [];

    // Get the main featured image ID
    $main_image_id = $product->get_image_id();
    if ($main_image_id) {
        $image_ids[] = $main_image_id;
    }

    // Get the gallery image IDs
    $gallery_image_ids = $product->get_gallery_image_ids();
    if (!empty($gallery_image_ids)) {
        $image_ids = array_merge($image_ids, $gallery_image_ids);
    }

    // If there are no images, return an empty array
    if (empty($image_ids)) {
        return [];
    }

    // Map all collected IDs to the desired structure
    return array_map(function($id) {
        return [
            'id'  => (int) $id,
            'src' => wp_get_attachment_url($id),
            'alt' => get_post_meta($id, '_wp_attachment_image_alt', true) ?: '',
        ];
    }, $image_ids);
}

function map_product_attributes($product) {
    $output = [];

    // 1. Map all product attributes
    foreach ($product->get_attributes() as $attribute) {
        if (!$attribute instanceof WC_Product_Attribute) {
            continue;
        }

        // For taxonomies (global attributes), get term names. For local ones, get options.
        if ($attribute->is_taxonomy()) {
            $options = wc_get_product_terms($product->get_id(), $attribute->get_name(), ['fields' => 'names']);
        } else {
            $options = $attribute->get_options();
        }

        $output[] = [
            'id'        => $attribute->get_id(),
            'name'      => wc_attribute_label($attribute->get_name()),
            'slug'      => $attribute->get_name(),
            'position'  => $attribute->get_position(),
            'visible'   => (bool) $attribute->get_visible(),
            'variation' => (bool) $attribute->get_variation(),
            'options'   => array_values($options),
        ];
    }

    return $output;
}

function map_product_default_attributes($product) {
    $output = [];
    if ($product->is_type('variable')) {
        foreach ($product->get_default_attributes() as $slug => $option_slug) {
            // Find the attribute ID and name from its slug
            $attribute_id = wc_attribute_taxonomy_id_by_name($slug);

            // Get the full term name from its slug (e.g., '1stk' -> '1stk')
            $term = get_term_by('slug', $option_slug, $slug);

            $output[] = [
                'id'     => (int) $attribute_id,
                'name'   => wc_attribute_label($slug),
                'option' => $term ? $term->name : $option_slug, // Use term name if available
            ];
        }
    }
    return $output;
}



function hundesport_map_category($term) {
    return [
        'id' => (int) $term->term_id,
        'name' => $term->name,
        'parent' => (int) $term->parent,
        'image' => function_exists('get_term_meta') ? [
            'src' => get_term_meta($term->term_id, 'thumbnail_id', true)
                ? wp_get_attachment_url(get_term_meta($term->term_id, 'thumbnail_id', true))
                : null,
        ] : null,
        'description' => $term->description,
    ];
}

function hundesport_map_product_base($p) {
    if (!$p || !is_a($p, 'WC_Product')) {
        return null;
    }

    $data = [
        'id' => $p->get_id(),
        'name' => $p->get_name(),
        'type' => $p->get_type(),
        'price' => (string) $p->get_price(),
        'regular_price' => (string) $p->get_regular_price(),
        'sale_price' => (string) $p->get_sale_price(),
        'on_sale' => $p->is_on_sale(),
        'featured' => $p->get_featured(),
        'stock_status' => $p->get_stock_status(),
        'description' => $p->get_description(),
        'short_description' => $p->get_short_description(),
        'parent_id' => $p->get_parent_id(),
    ];
    return $data;
}



function hundesport_map_product($p) {
    $data = hundesport_map_product_base($p);
    if (!$data) {
        return null;
    }

    $data['variations'] = $p->is_type('variable') ? $p->get_children() : [];
    $data['related_ids'] = $p->get_related();
    $data['default_attributes'] = $p->get_default_attributes();
    
    $category_ids = $p->get_category_ids();
    $terms = array_filter(array_map('get_term', $category_ids, array_fill(0, count($category_ids), 'product_cat')));
       $data['categories'] = array_map('hundesport_map_category', $terms);

    $data['images'] = map_product_images($p);
    $data['attributes'] =  map_product_attributes($p);
    $data['default_attributes'] =  map_product_default_attributes($p);
    return $data;
}
